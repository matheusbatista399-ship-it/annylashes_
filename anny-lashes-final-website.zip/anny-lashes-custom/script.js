const menuBtn=document.querySelector('.menu-btn');
const nav=document.querySelector('.nav');
menuBtn.addEventListener('click',()=>{const open=nav.classList.toggle('open');menuBtn.setAttribute('aria-expanded',String(open));});
document.querySelectorAll('.nav a').forEach(a=>a.addEventListener('click',()=>{nav.classList.remove('open');menuBtn.setAttribute('aria-expanded','false');}));
document.getElementById('year').textContent=new Date().getFullYear();

const looks={soft:['Natural look','Soft, subtle definition for an effortless everyday look. Ask Anny to confirm the service and price.','the natural look shown on your website','look-natural.png'],natural:['Classics · €55','A soft, defined look for an everyday lash moment.','Classics','look-classic.png'],wispy:['Brazilian Volume · €58','Soft fullness with a beautifully defined finish.','Brazilian Volume','look-brazilian.png'],glam:['Elegant look','Love this look? Ask Anny to confirm the lash style and price for your appointment.','the elegant look shown on your website','look-elegant.png']};
document.querySelectorAll('[data-vibe]').forEach(button=>button.addEventListener('click',()=>{document.querySelectorAll('[data-vibe]').forEach(b=>b.setAttribute('aria-pressed',String(b===button)));const [title,copy,style,img]=looks[button.dataset.vibe];document.getElementById('match-title').textContent=title;document.getElementById('match-copy').textContent=copy;document.getElementById('match-img').src='assets/'+img;document.getElementById('match-img').alt=style+' by Anny';document.getElementById('match-img').dataset.look=button.dataset.vibe;document.getElementById('match-book').href='https://wa.me/353871827842?text='+encodeURIComponent('Hi Anny, I’m interested in '+style+'. Could you help me choose my look?');}));
document.querySelector('.vibe-result').setAttribute('aria-live','polite');
const photoDialog=document.getElementById('photo-dialog');
document.querySelectorAll('.gallery-grid figure').forEach((figure,i)=>{const img=figure.querySelector('img');const button=document.createElement('button');button.setAttribute('aria-label','Enlarge lash photo '+(i+1));figure.append(button);button.append(img);button.addEventListener('click',()=>{const large=document.getElementById('large-photo');large.src=img.src;large.alt=img.alt;photoDialog.showModal();});});
document.getElementById('close-photo').addEventListener('click',()=>photoDialog.close());
photoDialog.addEventListener('click',event=>{if(event.target===photoDialog)photoDialog.close();});
